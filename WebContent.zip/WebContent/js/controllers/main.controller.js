(function () {
    'use strict';
 
    myModule
        .controller('MainController', MainController);
 
    MainController.$inject = ['$scope'];
    function MainController($scope) {
        var vm = this;
 
        vm.message = 'Welcome';
 
        (function initController() {
        	
            $scope.selectedItems = [];
            $scope.showAll = false;
        })();
 
    }
 
})();