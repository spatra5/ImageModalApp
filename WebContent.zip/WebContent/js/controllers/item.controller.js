(function () {
    'use strict';
 
    myModule
        .controller('ItemController', ItemController);
 
    ItemController.$inject = ['$scope', 'ItemService'];
    
    function ItemController($scope, ItemService) {
 
        (function initController() {
            //
        	$scope.items = [];
        	
        	ItemService.getItems()
            .then(
            	function(result) {
            		
            		$scope.items = result;
            		
            	}, function(error) {
            	
            		console.log(error.statusText);
            	}); 

        	
        })();
        
        
        $scope.showItem = function(id, index) {
        	
        	var items = $scope.items;
        	
        	if(items[index].selected) {

        		$scope.selectedItems.push(items[index]);

        	}
        	else {
        		for (var i = 0; i < $scope.selectedItems.length; i++) {
        			
                    var item = $scope.selectedItems[i];
                  
                    if (item.itemId === id) {
                    	$scope.selectedItems.splice(i, 1);
                        break;
                    }
                }
            	
        	}

        };
        
        $scope.showAllItems = function() {

    		$scope.showAll = !$scope.showAll;
    		$scope.selectedItems = [];
    		
        	if($scope.showAll) {
        		
        		$scope.setAllItemSelected(true);
        		
        		for(var i in $scope.items) {
        			$scope.selectedItems.push($scope.items[i]);
        		}
        	}
        	else {

        		$scope.setAllItemSelected(false);
        	}
        };
        
        $scope.showItemModal = function(item) {
        	
        	$scope.currentItem = item;
        };
        
        $scope.setAllItemSelected = function(flag) {
        	
        	for(var i in $scope.items) {
        		
        		$scope.items[i].selected= flag;
        	}
        };
        


        $scope.itemImgWidth = 100;

        $scope.increaseItemImgWidth = function(){
        	
        	if($scope.itemImgWidth != 200){
        		$scope.itemImgWidth+= 10;
        	}
        };

        $scope.decreaseItemImgWidth = function(){
        	
        	if($scope.itemImgWidth != 50){
        		$scope.itemImgWidth-= 10;
        	}
        };
        
        $scope.setFullItemImgWidth = function() {
        	
        	$scope.itemImgWidth = 100;
        };
        
    }
 
})();